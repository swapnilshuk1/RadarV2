import type { CardHandle, JobSnapshot, PortalContext, PortalHandler } from "../types";
import { SNAPSHOT_SCHEMA_VERSION, SCRAPER_VERSION } from "../versions";
import { CONFIG } from "../config";
import { cardHashFor } from "../utils/hash";
import { humanize, jitter, sleep } from "../utils/jitter";

const LINKEDIN_GEO_INDIA = "102713980";

export const linkedinHandler: PortalHandler = {
  name: "LinkedIn",
  buildSearchUrl(kw, page) {
    const start = (page - 1) * 25;
    return `https://www.linkedin.com/jobs/search/?keywords=${encodeURIComponent(kw)}&location=India&geoId=${LINKEDIN_GEO_INDIA}&start=${start}`;
  },
  async ensureSession(ctx) {
    const page = await ctx.browserContext.newPage();
    try {
      await page.goto("https://www.linkedin.com/feed/", { waitUntil: "domcontentloaded", timeout: CONFIG.navTimeoutMs });
      
      // Wait up to 8 seconds for the logged-in navigation bar or search input to render
      let loggedIn = false;
      try {
        await page.waitForSelector('.global-nav, .search-global-typeahead__input, input[placeholder*="Search" i]', { timeout: 8000 });
        loggedIn = true;
      } catch {
        const count = await page.locator('.global-nav, .search-global-typeahead__input').first().count().catch(() => 0);
        loggedIn = count > 0;
      }

      if (!loggedIn) {
        ctx.logger("LinkedIn not logged in — waiting up to 2 min for manual sign-in.");
        const deadline = Date.now() + CONFIG.captchaGateWaitMs;
        while (Date.now() < deadline) {
          const ok = await page.locator('.global-nav, .search-global-typeahead__input, input[placeholder*="Search" i]').first().count().catch(() => 0);
          if (ok) return "ready";
          await sleep(CONFIG.captchaPollMs);
        }
        return "gated";
      }
      return "ready";
    } catch (err: any) {
      ctx.logger(`LinkedIn session probe failed: ${err.message}`);
      return "error";
    } finally {
      await page.close().catch(() => {});
    }
  },
  async listCards(ctx) {
    const page = await ctx.browserContext.newPage();
    const handles: CardHandle[] = [];
    try {
      await page.goto(ctx.searchUrl, { waitUntil: "domcontentloaded", timeout: CONFIG.navTimeoutMs });
      await humanize(page);
      await sleep(2500);
      const cards = await page.locator("div.job-card-container, li.jobs-search-results__list-item").all();
      const sliced = cards.slice(0, CONFIG.maxCardsPerPage);
      for (const card of sliced) {
        try {
          const titleEl = card.locator('a.job-card-list__title, a.job-card-container__link').first();
          const title = ((await titleEl.textContent().catch(() => "")) || "").trim();
          const company = ((await card.locator(".job-card-container__primary-description, .artdeco-entity-lockup__subtitle").first().textContent().catch(() => "")) || "").trim();
          const location = ((await card.locator(".job-card-container__metadata-item, .artdeco-entity-lockup__caption").first().textContent().catch(() => "")) || "").trim();
          const href = ((await titleEl.getAttribute("href").catch(() => "")) || "").trim();
          if (!href || !title) continue;
          const detailUrl = href.startsWith("http") ? href : `https://www.linkedin.com${href}`;
          const cardHash = cardHashFor("LinkedIn", detailUrl);
          const rawHtml = await card.innerHTML().catch(() => "");
          const rawText = ((await card.textContent().catch(() => "")) || "").replace(/\s+/g, " ").trim();

          handles.push({
            cardHash,
            detailUrl,
            extractSnapshot: async () => {
              const detail = await fetchDetail(ctx, detailUrl);
              return buildSnapshot({
                ctx, cardHash, detailUrl,
                title, company, location, rawHtml, rawText, detail,
              });
            },
          });
        } catch (err: any) {
          ctx.logger(`LinkedIn card parse skipped: ${err.message}`);
        }
      }
    } catch (err: any) {
      ctx.logger(`LinkedIn listCards failed: ${err.message}`);
    } finally {
      await page.close().catch(() => {});
    }
    return handles;
  },
};

async function fetchDetail(ctx: PortalContext, url: string) {
  const t0 = Date.now();
  const page = await ctx.browserContext.newPage();
  try {
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: CONFIG.detailTimeoutMs });
    await jitter(600, 1400);
    await page.locator('button[aria-label*="see more" i], .show-more-less-html__button').first().click({ timeout: 1500 }).catch(() => {});
    const container = page.locator(".jobs-description__content, .description__text, .show-more-less-html__markup").first();
    const rawHtml = await container.innerHTML().catch(() => "");
    const rawText = ((await container.textContent().catch(() => "")) || "").replace(/\s+/g, " ").trim();
    return { fetched: true, rawHtml, rawText, fetchDurationMs: Date.now() - t0 };
  } catch (err: any) {
    return { fetched: false, fetchError: err.message, fetchDurationMs: Date.now() - t0 };
  } finally {
    // Close detail tab explicitly to avoid tab bloat under parallel card work.
    await page.close().catch(() => {});
  }
}

function buildSnapshot(args: any): JobSnapshot {
  const { ctx, cardHash, detailUrl, title, company, location, rawHtml, rawText, detail } = args;
  return {
    snapshotSchemaVersion: SNAPSHOT_SCHEMA_VERSION,
    scraperVersion: SCRAPER_VERSION,
    cardHash,
    portal: "LinkedIn",
    keyword: ctx.keyword,
    discoveredAt: new Date().toISOString(),
    searchUrl: ctx.searchUrl,
    detailUrl,
    card: { rawHtml, rawText, title, company, location },
    detail,
    telemetry: { cardExtractMs: 0, detailExtractMs: detail.fetchDurationMs || 0, totalMs: detail.fetchDurationMs || 0 },
  };
}
